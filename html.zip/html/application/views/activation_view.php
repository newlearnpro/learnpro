<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>



<div><h2>Դուք ակտիվացրել եք ձեր գրանցումը</h2></div>