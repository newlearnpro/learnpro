function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6e1fCbioS0q":
        Script1();
        break;
      case "6NspUMZSDok":
        Script2();
        break;
      case "6WClgAeFj6e":
        Script3();
        break;
      case "6r7tPTWmq1u":
        Script4();
        break;
      case "6pTr0kcU6w3":
        Script5();
        break;
      case "6hrcj4LUJYw":
        Script6();
        break;
      case "6coEGwIy6Sh":
        Script7();
        break;
      case "5p7zbKeQgsp":
        Script8();
        break;
      case "5eQxGbIjGEs":
        Script9();
        break;
  }
}

function Script1()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script2()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script3()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script4()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script5()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script6()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script7()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script8()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

function Script9()
{
  parent.document.getElementsByClassName("lesson_selected")[0].parentElement.firstElementChild.click();
}

