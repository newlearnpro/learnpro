



	<footer>

	</footer>
	<script type="text/javascript" src="<?=base_url();?>/public/js/app/services.js"></script>
	<script type="text/javascript" src="<?=base_url();?>/public/js/app/filters.js"></script>
    <script type="text/javascript" src="<?=base_url();?>/public/js/app/script.js"></script>
    <script type="text/javascript" src="<?=base_url();?>/public/js/app/ctrl_listgroup.js"></script>


</body>
</html>